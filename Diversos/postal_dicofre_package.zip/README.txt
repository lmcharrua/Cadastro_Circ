Postal Code to DICOFRE Mapping
----------------------------------
This dataset maps each Portuguese postal code (Código Postal) to the corresponding DICOFRE code (freguesia identifier).

Sources:
- cod_post_freg_matched.csv (DSSG-PT project)
- freguesias-metadata.xlsx (Anacom / DICOFRE metadata)

Columns:
- codigo_postal: Portuguese postal code
- freguesia: Name of the civil parish
- concelho: Municipality
- distrito: District
- dicofre: Official DICOFRE code

Join method: merged by lowercase-normalized (freguesia, concelho, distrito).
Some unmatched cases may exist due to naming variations.
