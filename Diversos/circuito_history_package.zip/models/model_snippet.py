from django.db import models
from simple_history.models import HistoricalRecords

class Circuitos(models.Model):
    N_Circuito = models.CharField(max_length=50, unique=True)
    Data_Rate = models.CharField(max_length=50, blank=True, null=True)
    Data_Inst = models.DateField(blank=True, null=True)
    Data_Activ = models.DateField(blank=True, null=True)
    Estado_Cct = models.CharField(max_length=50, default='Definido')
    Propriedade_Cct = models.CharField(max_length=100, blank=True, null=True)
    User_Cct = models.CharField(max_length=100, blank=True, null=True)
    Outras_Ref = models.TextField(blank=True, null=True)
    # other fields...

    history = HistoricalRecords()

    def __str__(self):
        return self.N_Circuito
