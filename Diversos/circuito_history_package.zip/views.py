from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Circuitos
from .forms import CircuitoForm, CreateCircuitoForm
from cmain.decorators import group_required


@login_required(login_url='userlogin')
@group_required(('NOC', 'TX', 'DAT', 'DADOS', 'VOZ'))
def lista_cct(request):
    l_circuitos = Circuitos.objects.exclude(Estado_Cct="Desligado")
    context = {'circuitos': l_circuitos}
    return render(request, 'circuitos/lista_circuitos.html', context=context)


@login_required(login_url='userlogin')
@group_required(('NOC', 'TX', 'DAT', 'DADOS', 'VOZ'))
def ver_circuito(request, pk):
    all_circuitos = get_object_or_404(Circuitos, id=pk)
    context = {'circuito': all_circuitos}
    return render(request, 'circuitos/ver_circuito.html', context=context)


@login_required(login_url='userlogin')
@group_required(('TX', 'DAT', 'DADOS', 'VOZ'))
def editar_circuito(request, pk):
    circuito = get_object_or_404(Circuitos, id=pk)
    form = CircuitoForm(request.POST or None, instance=circuito)
    can_edit = request.user.has_perm('circuitos.change_circuitos')

    if request.method == 'POST' and can_edit:
        if form.is_valid():
            circuito = form.save(commit=False)
            circuito._change_reason = request.POST.get('history_change_reason', 'Edição sem motivo especificado')
            circuito.save()
            form.save_m2m()
            messages.success(request, "O circuito foi atualizado com sucesso!")
            return redirect("lista_cct")

    context = {'form': form, 'can_edit': can_edit}
    return render(request, 'circuitos/editar_circuito.html', context=context)


@login_required(login_url='userlogin')
@group_required(('TX', 'DAT', 'DADOS'))
def criar_circuito(request):
    form = CreateCircuitoForm(request.POST or None)
    if request.method == "POST":
        if form.is_valid():
            circuito = form.save(commit=False)
            circuito._change_reason = "Criação de circuito"
            circuito.save()
            messages.success(request, "O circuito foi criado com sucesso!")
            return redirect('lista_cct')

    context = {'form': form}
    return render(request, 'circuitos/criar_circuito.html', context=context)
